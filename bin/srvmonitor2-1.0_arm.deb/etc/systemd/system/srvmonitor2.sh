#!/usr/bin/basj

/usr/bin/srvmonitor2

